import streamlit as st
import pandas as pd
import plotly.express as px
import time

#import setuptools

st.set_page_config(layout= 'wide')

# Carregar os dados
data = pd.read_csv('dados_processados.csv')

# Título
st.title("Dashboard de Autenticações")
st.markdown("***")


col1, col2= st.columns(2)

with col1:
    # Número total de autenticações
    total_autenticacoes = data.shape[0]
    st.metric("Número Total de Autenticações", total_autenticacoes)

    # Separar autenticações por status
    status_counts = data['Status'].value_counts()

    # Autenticações bem-sucedidas vs incorretas
    st.subheader("Status de Autenticações")
    st.bar_chart(status_counts)

    # Usuários com mais tentativas de login
    top_users = data['Email'].value_counts().head(10) 
    st.subheader("Top 10 Usuários com mais Tentativas de Login")
    st.bar_chart(top_users)

with col2:

    # Número total de autenticações
    total_autenticacoes = data.shape[0]
    st.metric("Número Total de Autenticações", total_autenticacoes)

    # Distribuição por cliente
    client_distribution = data['Client'].value_counts()
    st.subheader("Distribuição por Cliente")

    # Usando Plotly para o gráfico de pizza
    fig = px.pie(names=client_distribution.index, values=client_distribution.values)
    st.plotly_chart(fig)

    # Distribuição por mês
    month_distribution = data['Mês'].value_counts()
    st.subheader("Distribuição de Autenticações")
    st.bar_chart(month_distribution)

    # Título
    st.subheader("Pesquisa de dados por usuário")

    # Carregar os dados (substitua pelo caminho correto do arquivo CSV ou o dataframe)
    dados_df = data

    # Entrada para o email do usuário
    usuario_input = st.text_input("Informe o email do usuário:")

    # Verificar se o usuário foi informado
    if usuario_input:
        # Verificar se a coluna 'Status' existe no DataFrame
        if 'Status' in dados_df.columns:
            # Filtrar as tentativas de logins com erro para o usuário informado
            tentativas_erro_usuario = dados_df[(dados_df['Email'] == usuario_input) & (dados_df['Status'] == 'Login incorrect')]

            # Verificar se existem tentativas de login com erro para o usuário informado
            if not tentativas_erro_usuario.empty:
                # Agrupar por usuário, erro e data, contando as tentativas de login com erro
                tentativas_erro_por_usuario_erro_data = tentativas_erro_usuario.groupby(['Email', 'Error', 'Data']).size()

                # Filtrar os erros para o usuário com mais de 10 tentativas de login com erro
                usuarios_com_mais_de_10_erros = tentativas_erro_por_usuario_erro_data[tentativas_erro_por_usuario_erro_data > 10]

                # Função para criar o estilo da caixa
                def criar_box(usuario, error, tentativas, data, horario_min, horario_max, rede):
                    st.markdown(
                        f"""
                        <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; background-color: #f9f9f9; margin-bottom: 10px;">
                            <strong>Usuário:</strong> {usuario}<br>
                            <strong>Erro:</strong> {error}<br>
                            <strong>Tentativas de login com erro:</strong> {tentativas}<br>
                            <strong>Data:</strong> {data}<br>
                            <strong>Intervalo de Horários:</strong> {horario_min} - {horario_max}<br>
                            <strong>Rede:</strong> {', '.join(rede)}<br>
                        </div>
                        """, unsafe_allow_html=True
                    )

                # Verificar se há usuários com mais de 10 tentativas de login com erro
                if not usuarios_com_mais_de_10_erros.empty:
                    st.warning(f"Alerta: O usuário {usuario_input} tem mais de 10 tentativas de login com erro!")
                    
                    # Loop pelos erros e detalhes das tentativas
                    for (usuario, error, data), tentativas in usuarios_com_mais_de_10_erros.items():
                        # Detalhes das tentativas para esse usuário, erro e data específicos
                        detalhes_tentativas = tentativas_erro_usuario[(tentativas_erro_usuario['Error'] == error) & (tentativas_erro_usuario['Data'] == data)]
                        
                        # Coletar informações para exibir
                        horario_min = detalhes_tentativas['Horário'].min()
                        horario_max = detalhes_tentativas['Horário'].max()
                        rede = detalhes_tentativas['Client'].unique()

                        # Chamar a função para exibir os detalhes em um box estilizado
                        criar_box(usuario, error, tentativas, data, horario_min, horario_max, rede)
                else:
                    st.info(f"O usuário {usuario_input} não tem mais de 10 tentativas de login com erro.")
            else:
                st.info(f"Não há tentativas de login com erro para o usuário {usuario_input}.")
        else:
            st.error("A coluna 'Status' não foi encontrada no DataFrame.")


with col1:
    dados_df = (data)
    # Título
    st.subheader("Últimos alertas")
    
    # Contar as tentativas de login com erro dos usuários
    tentativas_erro = dados_df[dados_df['Status'] == 'Login incorrect']

    # Agrupar por usuário, erro e data, contando as tentativas de login com erro
    tentativas_erro_por_usuario_erro_data = tentativas_erro.groupby(['Email', 'Error', 'Data']).size()

    # Filtrar os usuários com mais de 10 tentativas de login com erro
    usuarios_com_mais_de_10_erros = tentativas_erro_por_usuario_erro_data[tentativas_erro_por_usuario_erro_data > 10]

    # Reordenar para pegar os 3 últimos (mais recentes)
    usuarios_com_mais_de_10_erros = usuarios_com_mais_de_10_erros.sort_index(ascending=False)

    # Inicializar contador de saídas e limitador
    contador_saidas = 0
    limite_alertas = 3

    # Função para criar o estilo da caixa
    def criar_box(usuario, error, tentativas, data, horario_min, horario_max, rede):
        st.markdown(
            f"""
            <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; background-color: #f9f9f9; margin-bottom: 10px;">
                <strong>Usuário:</strong> {usuario}<br>
                <strong>Erro:</strong> {error}<br>
                <strong>Tentativas de login com erro:</strong> {tentativas}<br>
                <strong>Data:</strong> {data}<br>
                <strong>Intervalo de Horários:</strong> {horario_min} - {horario_max}<br>
                <strong>Rede:</strong> {', '.join(rede)}<br>
            </div>
            """, unsafe_allow_html=True
        )

    # Verificar se há usuários com mais de 10 tentativas de login com erro
    if not usuarios_com_mais_de_10_erros.empty:
        st.warning("Alerta: Existem usuários com mais de 10 tentativas de login com erro!")
        
        # Loop pelos últimos 3 usuários com mais de 10 tentativas de login incorretas
        for (usuario, error, data), tentativas in usuarios_com_mais_de_10_erros.items():
            if contador_saidas >= limite_alertas:
                break  # Para o loop após atingir o limite de 3 alertas
            
            # Detalhes das tentativas para esse usuário, erro e data específicos
            detalhes_tentativas = dados_df[(dados_df['Email'] == usuario) & (dados_df['Error'] == error) & (dados_df['Data'] == data)]
            
            horario_min = detalhes_tentativas['Horário'].min()
            horario_max = detalhes_tentativas['Horário'].max()
            rede = detalhes_tentativas['Client'].unique()
            
            # Chamar a função para exibir os detalhes em um box estilizado
            criar_box(usuario, error, tentativas, data, horario_min, horario_max, rede)
            
            # Incrementa o contador de saídas para cada alerta gerado
            contador_saidas += 1
    else:
        st.info("Não há usuários com mais de 10 tentativas de login com erro.")


# Verificar se 'data' é um DataFrame válido e contém a coluna 'Data'
if isinstance(data, pd.DataFrame) and 'Data' in data.columns:
    # Converter a coluna 'Data' para o formato datetime
    data['Data'] = pd.to_datetime(data['Data'], errors='coerce')
    dados_df = data  # Confirmando que data é um DataFrame

    # Filtrar apenas as tentativas de login com erro
    tentativas_erro = dados_df[dados_df['Status'] == 'Login incorrect']

    # Verificar se existem tentativas de login com erro
    if not tentativas_erro.empty:
        # Contar a ocorrência de cada tipo de erro
        erros_comuns = tentativas_erro['Error'].value_counts().reset_index()
        erros_comuns.columns = ['Erro', 'Ocorrências']

        # Exibir tabela com os erros mais comuns
        st.subheader("Erros de Login Mais Comuns")
        st.table(erros_comuns)

        # Exibir gráfico dos erros mais comuns
        fig = px.bar(
            erros_comuns, 
            x='Erro', 
            y='Ocorrências', 
            title="Erros de Login Mais Comuns",
            labels={'Erro': 'Tipo de Erro', 'Ocorrências': 'Número de Ocorrências'},
            text='Ocorrências'
        )
        fig.update_traces(textposition='outside')
        fig.update_layout(xaxis_title="Erro", yaxis_title="Ocorrências", uniformtext_minsize=8, uniformtext_mode='hide')

        # Mostrar o gráfico no Streamlit
        st.plotly_chart(fig)
    else:
        st.info("Não há tentativas de login com erro registradas nos dados.")
else:
    st.error("Erro: O 'data' não é um DataFrame válido ou não contém a coluna 'Data'. Verifique se o arquivo foi carregado corretamente.")


