import streamlit as st
import requests
import pandas as pd
import time

st.set_page_config(layout= 'wide')

@st.cache_data
def converte_csv(df):
    return df.to_csv(index =  False).encode('utf-8')

def mensagem_sucesso():
    sucesso = st.success('Arquivo baixado com sucesso!', icon="✅" )
    time.sleep(5)
    sucesso.empty()

# Título
st.title("Dados de Autenticações 📄")

# Carregar os dados
dados_df = pd.read_csv('dados_processados.csv')
st.write(dados_df)

###
# Sidebar para filtros
st.sidebar.title('Filtros')

# Converter a coluna 'Data' para o formato datetime, caso não esteja
dados_df['Data'] = pd.to_datetime(dados_df['Data'], errors='coerce')

# Função auxiliar para verificar se uma coluna existe no DataFrame e lidar com NaN
def obter_valores_unicos(df, coluna):
    if coluna in df.columns:
        return df[coluna].dropna().unique()  # Remove os valores NaN
    return []

# Variável para rastrear se algum filtro foi aplicado
filtros_aplicados = False

# Filtros na sidebar, usando expander para agrupar por categoria
with st.sidebar.expander('Dia da Semana'):
    dias_semana = st.multiselect('Selecione os dias da semana', obter_valores_unicos(dados_df, 'Dia da Semana'))
    if dias_semana:
        filtros_aplicados = True

with st.sidebar.expander('Ano'):
    anos = st.multiselect('Selecione o ano', obter_valores_unicos(dados_df, 'Ano'))
    if anos:
        filtros_aplicados = True

with st.sidebar.expander('Mês'):
    mes = st.multiselect('Selecione o Mês', obter_valores_unicos(dados_df, 'Mês'))
    if anos:
        filtros_aplicados = True

with st.sidebar.expander('Autenticação'):
    autenticacao = st.multiselect('Selecione o tipo de autenticação', obter_valores_unicos(dados_df, 'Autenticação'))
    if autenticacao:
        filtros_aplicados = True

with st.sidebar.expander('Status'):
    status = st.multiselect('Selecione o status', obter_valores_unicos(dados_df, 'Status'))
    if status:
        filtros_aplicados = True

with st.sidebar.expander('Email'):
    emails = st.multiselect('Selecione o email', obter_valores_unicos(dados_df, 'Email'))
    if emails:
        filtros_aplicados = True

with st.sidebar.expander('Client'):
    clients = st.multiselect('Selecione o Client', obter_valores_unicos(dados_df, 'Client'))
    if clients:
        filtros_aplicados = True

with st.sidebar.expander('Data'):
    data_selecionada = st.date_input('Selecione a data', (dados_df['Data'].min().date(), dados_df['Data'].max().date()))
    if data_selecionada:
        filtros_aplicados = True

# Aplicar filtros aos dados
dados_filtrados = dados_df.copy()

# Aplicar cada filtro conforme a seleção do usuário
if dias_semana:
    dados_filtrados = dados_filtrados[dados_filtrados['Dia da Semana'].isin(dias_semana)]

if anos:
    dados_filtrados = dados_filtrados[dados_filtrados['Ano'].isin(anos)]

if autenticacao:
    dados_filtrados = dados_filtrados[dados_filtrados['Autenticação'].isin(autenticacao)]

if status:
    dados_filtrados = dados_filtrados[dados_filtrados['Status'].isin(status)]

if emails:
    dados_filtrados = dados_filtrados[dados_filtrados['Email'].isin(emails)]

if clients:
    dados_filtrados = dados_filtrados[dados_filtrados['Client'].isin(clients)]

if data_selecionada:
    if isinstance(data_selecionada, tuple):
        # Comparando com valores no formato datetime.date
        dados_filtrados = dados_filtrados[
            (dados_filtrados['Data'].dt.date >= data_selecionada[0]) & 
            (dados_filtrados['Data'].dt.date <= data_selecionada[1])
        ]
    else:
        dados_filtrados = dados_filtrados[dados_filtrados['Data'].dt.date == data_selecionada]

# Verificar se algum filtro foi aplicado
if filtros_aplicados:
    # Exibir os dados filtrados apenas se algum filtro foi aplicado
    if not dados_filtrados.empty:
        st.subheader("Dados Filtrados")
        st.write(dados_filtrados)

        # Botão para baixar os dados filtrados
        st.subheader("Baixar Dados Filtrados")
        
        # Função para converter os dados filtrados em CSV
        def converter_csv(df):
            return df.to_csv(index=False).encode('utf-8')

        csv = converter_csv(dados_filtrados)

        st.download_button(
            label="Baixar como CSV",
            data=csv,
            file_name='dados_filtrados.csv',
            mime='text/csv',
        )
    else:
        st.info("Não há dados que correspondem aos filtros selecionados.")
else:
    st.info("Aplique um ou mais filtros para visualizar os dados.")