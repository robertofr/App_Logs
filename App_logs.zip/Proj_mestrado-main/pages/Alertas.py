import streamlit as st
import requests
import pandas as pd
import time
from datetime import datetime, timedelta

# Título
st.title("Alertas")

## Visualização no streamlit
aba1, aba2, aba3 = st.tabs(['Login Recusadas Repetidamente', 'Logins em mais de 5 dispositivo', 'Tentativas bem sucedidas'])

# Carregar os dados (substitua pelo caminho correto do arquivo CSV ou o dataframe)
dados_df = pd.read_csv('dados_processados.csv')

# Tentativas de Login Recusadas Repetidamente por Usuário
with aba1:

    # Converter a coluna 'Data' para o formato datetime
    dados_df['Data'] = pd.to_datetime(dados_df['Data'], errors='coerce')

    # Sidebar para filtros de data
    st.sidebar.title("Filtros de Data")

    # Filtragem por semana, mês e ano
    opcao_filtro = st.sidebar.selectbox("Filtrar por", ["Nenhum", "Semana", "Mês", "Ano"])

    if opcao_filtro == "Semana":
        semana_selecionada = st.sidebar.number_input("Selecione a semana do ano", min_value=1, max_value=52)
        dados_df['Semana'] = dados_df['Data'].dt.isocalendar().week
        dados_filtrados = dados_df[dados_df['Semana'] == semana_selecionada]

    elif opcao_filtro == "Mês":
        mes_selecionado = st.sidebar.selectbox("Selecione o mês", range(1, 13))
        dados_filtrados = dados_df[dados_df['Data'].dt.month == mes_selecionado]

    elif opcao_filtro == "Ano":
        ano_selecionado = st.sidebar.selectbox("Selecione o ano", dados_df['Data'].dt.year.unique())
        dados_filtrados = dados_df[dados_df['Data'].dt.year == ano_selecionado]

    else:
        # Se nenhum filtro for aplicado, exibir todos os dados
        dados_filtrados = dados_df.copy()

    # Título
    st.subheader("Tentativas de Login Recusadas Repetidamente por Usuário")

    # Filtrar tentativas de login com erro
    tentativas_erro = dados_filtrados[dados_filtrados['Status'] == 'Login incorrect']

    # Agrupar por usuário, erro e data, contando as tentativas de login com erro
    tentativas_erro_por_usuario_erro_data = tentativas_erro.groupby(['Email', 'Error', 'Data']).size()

    # Filtrar os usuários com mais de 10 tentativas de login com erro
    usuarios_com_mais_de_10_erros = tentativas_erro_por_usuario_erro_data[tentativas_erro_por_usuario_erro_data > 10]

    # Reordenar para exibir do mais recente para o mais antigo
    usuarios_com_mais_de_10_erros = usuarios_com_mais_de_10_erros.sort_index(ascending=False)

    # Inicializar contador de saídas
    contador_saidas = 0

    # Função para criar o estilo da caixa
    def criar_box(usuario, error, tentativas, data, horario_min, horario_max, rede):
        st.markdown(
            f"""
            <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; background-color: #f9f9f9; margin-bottom: 10px;">
                <strong>Usuário:</strong> {usuario}<br>
                <strong>Erro:</strong> {error}<br>
                <strong>Tentativas de login com erro:</strong> {tentativas}<br>
                <strong>Data:</strong> {data}<br>
                <strong>Intervalo de Horários:</strong> {horario_min} - {horario_max}<br>
                <strong>Rede:</strong> {', '.join(rede)}<br>
            </div>
            """, unsafe_allow_html=True
        )

    # Verificar se há usuários com mais de 10 tentativas de login com erro
    if not usuarios_com_mais_de_10_erros.empty:
        st.warning("Alerta: Existem usuários com mais de 10 tentativas de login com erro!")
        
        # Loop pelos usuários com mais de 10 tentativas de login incorretas (do mais recente para o mais antigo)
        for (usuario, error, data), tentativas in usuarios_com_mais_de_10_erros.items():
            
            # Detalhes das tentativas para esse usuário, erro e data específicos
            detalhes_tentativas = dados_filtrados[(dados_filtrados['Email'] == usuario) & (dados_filtrados['Error'] == error) & (dados_filtrados['Data'] == data)]
            
            # Coletar informações para exibir
            horario_min = detalhes_tentativas['Horário'].min()
            horario_max = detalhes_tentativas['Horário'].max()
            rede = detalhes_tentativas['Client'].unique()

            # Chamar a função para exibir os detalhes em um box estilizado
            criar_box(usuario, error, tentativas, data, horario_min, horario_max, rede)
            
            # Incrementa o contador de saídas para cada alerta gerado
            contador_saidas += 1
    else:
        st.info("Não há usuários com mais de 10 tentativas de login com erro.")

    # Mostrar o total de saídas geradas
    st.write(f"Total de saídas geradas: {contador_saidas}")

# Logins em mais de 5 dispositivos distintos
with aba2:

    # Título
    st.subheader("Logins em mais de 5 MAC Address Distintos")

    # Agrupar por usuário e data, contando os MAC Address distintos
    logins_por_usuario_data_mac = dados_df.groupby(['Email', 'Data'])['MAC Address'].nunique()

    # Filtrar os usuários com mais de 5 logins em MAC Address distintos no mesmo dia
    usuarios_com_mais_de_5_logins = logins_por_usuario_data_mac[logins_por_usuario_data_mac > 5]

    # Ordenar do mais recente para o mais antigo
    usuarios_com_mais_de_5_logins = usuarios_com_mais_de_5_logins.sort_index(ascending=False)

    # Inicializar contador
    contador_alertas = 0

    # Função para criar o estilo da caixa
    def criar_box(usuario, data, qtd_logins, mac_addresses, client):
        st.markdown(
            f"""
            <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; background-color: #f9f9f9; margin-bottom: 10px;">
                <strong>Usuário:</strong> {usuario}<br>
                <strong>Data:</strong> {data}<br>
                <strong>Quantidade de logins ativos:</strong> {qtd_logins}<br>
                <strong>MAC Address dos dispositivos conectados simultaneamente:</strong> {', '.join(mac_addresses)}<br>
                <strong>Client:</strong> {client}<br>
            </div>
            """, unsafe_allow_html=True
        )

    # Verificar se há usuários com mais de 5 logins em MAC Address distintos
    if not usuarios_com_mais_de_5_logins.empty:
        st.warning("Alerta: Existem usuários com mais de 5 logins simultâneos em MAC Address distintos!")
        
        # Iterar sobre os usuários com mais de 5 logins em MAC Address distintos
        for (usuario, data), qtd_logins in usuarios_com_mais_de_5_logins.items():
            
            # Filtrar os dados para o usuário e data específicos
            dados_usuario_data = dados_df[(dados_df['Email'] == usuario) & (dados_df['Data'] == data)]
            
            # Obter os MAC Address distintos
            mac_address_distintos = dados_usuario_data['MAC Address'].unique()
            
            # Verificar se há mais de 5 logins ativos
            if len(mac_address_distintos) > 5:
                # Obter o client
                client = dados_usuario_data['Client'].iloc[0]
                
                # Chamar a função para exibir os detalhes em um box estilizado
                criar_box(usuario, data, len(mac_address_distintos), mac_address_distintos, client)
                
                # Incrementar o contador de alertas
                contador_alertas += 1
    else:
        st.info("Não há usuários com mais de 5 logins em MAC Address distintos no mesmo dia.")

    # Mostrar o total de alertas gerados
    st.write(f"Total de alertas gerados: {contador_alertas}")


# Tentativas bem sucedidas em intervalos de tempo curtos
with aba3:
    # Título
    st.subheader("Tentativas bem sucedidas em intervalos de tempo curtos")
    # Agrupar por usuário, data e hora, contando os MAC Address distintos
    logins_por_usuario_data_hora_mac = dados_df.groupby(['Email', 'Data', 'Hora'])['MAC Address'].nunique()

    # Filtrar os usuários com mais de 5 logins em MAC Address distintos no mesmo dia e horário
    usuarios_com_mais_de_5_logins = logins_por_usuario_data_hora_mac[logins_por_usuario_data_hora_mac > 4]

    # Ordenar do mais recente para o mais antigo (por Data e Hora) 
    usuarios_com_mais_de_5_logins = usuarios_com_mais_de_5_logins.sort_index(ascending=False)

    # Inicializar contador
    contador_alertas = 0

    # Função para criar o estilo da caixa
    def criar_box(usuario, data, hora, qtd_logins, mac_addresses, client):
        st.markdown(
            f"""
            <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; background-color: #f9f9f9; margin-bottom: 10px;">
                <strong>Usuário:</strong> {usuario}<br>
                <strong>Data:</strong> {data}<br>
                <strong>Hora:</strong> {hora}<br>
                <strong>Quantidade de logins ativos:</strong> {qtd_logins}<br>
                <strong>MAC Address dos dispositivos conectados simultaneamente:</strong> {', '.join(mac_addresses)}<br>
                <strong>Client:</strong> {client}<br>
            </div>
            """, unsafe_allow_html=True
        )

    # Verificar se há usuários com mais de 4 logins simultâneos em MAC Address distintos
    if not usuarios_com_mais_de_5_logins.empty:
        st.warning("Alerta: Existem usuários com mais de 5 logins simultâneos em MAC Address distintos!")
        
        # Loop pelos usuários com mais de 5 logins simultâneos em MAC Address distintos
        for (usuario, data, hora), qtd_logins in usuarios_com_mais_de_5_logins.items():
            
            # Filtrar os dados para o usuário, data e hora específicos
            dados_usuario_data_hora = dados_df[(dados_df['Email'] == usuario) & (dados_df['Data'] == data) & (dados_df['Hora'] == hora)]
            
            # Obter os MAC Address distintos
            mac_address_distintos = dados_usuario_data_hora['MAC Address'].unique()
            
            # Obter o client
            client = dados_usuario_data_hora['Client'].iloc[0]
            
            # Chamar a função para exibir os detalhes em um box estilizado
            criar_box(usuario, data, hora, len(mac_address_distintos), mac_address_distintos, client)
            
        # Incrementar o contador de alertas
        contador_alertas += 1
    else:
        st.info("Não há usuários com mais de 5 logins simultâneos em MAC Address distintos no mesmo dia e horário.")

    # Mostrar o total de saídas geradas
    st.write(f"Total de saídas geradas: {contador_saidas}")
