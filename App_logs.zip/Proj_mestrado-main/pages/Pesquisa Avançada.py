import streamlit as st
import pandas as pd
import plotly.express as px

# Carregar os dados
data= pd.read_csv('dados_processados.csv')

# Título
st.subheader("Pesquisa Avançadas")

## Visualização no streamlit
aba1, aba2, aba3 = st.tabs(['Pesquisa por usuário', 'Pesquisa por data', 'Linha do tempo'])

with aba1:
   
    st.subheader("Pesquisa por usuário")

    # Verificar se 'data' é um DataFrame válido e contém a coluna 'Data'
    if isinstance(data, pd.DataFrame) and 'Data' in data.columns:
        # Converter a coluna 'Data' para o formato datetime
        data['Data'] = pd.to_datetime(data['Data'], errors='coerce')
        dados_df = data  # Confirmando que data é um DataFrame

        # Entrada para o email ou parte do email do usuário
        usuario_input = st.text_input("Informe o email do usuário ou parte dele:")
        # Adiciona o botão de busca
        pesquisar = st.button("Pesquisar")

        # Verificar se o usuário foi informado
        if pesquisar and usuario_input:
            # Filtrar tentativas de logins com erro para o usuário informado
            tentativas_erro_usuario = dados_df[dados_df['Email'].str.contains(usuario_input, case=False, na=False) & (dados_df['Status'] == 'Login incorrect')]

            # Verificar se existem tentativas de login com erro para o usuário informado
            if not tentativas_erro_usuario.empty:
                # Agrupar por usuário, erro e data, contando as tentativas de login com erro
                tentativas_erro_por_usuario_erro_data = tentativas_erro_usuario.groupby(['Email', 'Error', 'Data']).size()

                # Exibir o alerta de tentativas de login com erro
                st.warning(f"Alerta: O usuário {usuario_input} tem tentativas de login com erro!")

                # Função para criar o estilo da caixa
                def criar_box(usuario, error, tentativas, data_str, horario_min, horario_max, rede):
                    st.markdown(
                        f"""
                        <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; background-color: #f9f9f9; margin-bottom: 10px;">
                            <strong>Usuário:</strong> {usuario}<br>
                            <strong>Erro:</strong> {error}<br>
                            <strong>Tentativas de login com erro:</strong> {tentativas}<br>
                            <strong>Data:</strong> {data_str}<br>
                            <strong>Intervalo de Horários:</strong> {horario_min} - {horario_max}<br>
                            <strong>Rede:</strong> {', '.join(rede)}<br>
                        </div>
                        """, unsafe_allow_html=True
                    )

                # Loop pelos erros e detalhes das tentativas
                for (usuario, error, data_timestamp), tentativas in tentativas_erro_por_usuario_erro_data.items():
                    # Converter `data_timestamp` para string
                    data_str = data_timestamp.strftime("%Y-%m-%d") if isinstance(data_timestamp, pd.Timestamp) else data_timestamp

                    # Detalhes das tentativas para esse usuário, erro e data específicos
                    detalhes_tentativas = tentativas_erro_usuario[(tentativas_erro_usuario['Error'] == error) & (tentativas_erro_usuario['Data'] == data_timestamp)]

                    # Coletar informações para exibir
                    horario_min = detalhes_tentativas['Horário'].min()
                    horario_max = detalhes_tentativas['Horário'].max()
                    rede = detalhes_tentativas['Client'].unique()

                    # Exibir os detalhes em um box estilizado
                    criar_box(usuario, error, tentativas, data_str, horario_min, horario_max, rede)
            else:
                st.info(f"Não há tentativas de login com erro para o usuário {usuario_input}.")
    else:
        st.error("Erro: O 'data' não é um DataFrame válido ou não contém a coluna 'Data'. Verifique se o arquivo foi carregado corretamente.")


with aba2: 

    col1, col2= st.columns(2)
    # Função para filtrar dados
    st.subheader("Filtro por data")
    with col1:
        start_date = st.date_input("Data Inicial")
    with col2:
        end_date = st.date_input("Data Final")

    # Filtrar com base nas datas
    filtered_data = data[(pd.to_datetime(data['Data']) >= pd.to_datetime(start_date)) &
                        (pd.to_datetime(data['Data']) <= pd.to_datetime(end_date))]

    st.write(f"Número de registros entre {start_date} e {end_date}: {filtered_data.shape[0]}")
    st.dataframe(filtered_data)

with aba3:
    st.subheader("Linha do tempo")

    # Verificar se 'data' é um DataFrame válido e contém a coluna 'Data'
    if isinstance(data, pd.DataFrame) and 'Data' in data.columns:
        # Converter a coluna 'Data' para o formato datetime
        data['Data'] = pd.to_datetime(data['Data'], errors='coerce')
        dados_df = data  # Confirmando que data é um DataFrame

        # Entrada para o email ou parte do email do usuário
        usuario_input = st.text_input("Informe o email do usuário ou parte dele:", key="usuario_email_input")
        # Adiciona o botão de busca com uma chave única
        pesquisar = st.button("Pesquisar", key="pesquisar_botao")

        # Verificar se o usuário foi informado e se o botão foi pressionado
        if usuario_input and pesquisar:
            # Filtrar tentativas de logins com erro para o usuário informado (usando 'contains' para aceitar parte do email)
            tentativas_erro_usuario = dados_df[dados_df['Email'].str.contains(usuario_input, case=False, na=False) & (dados_df['Status'] == 'Login incorrect')]

            # Verificar se existem tentativas de login com erro para o usuário informado
            if not tentativas_erro_usuario.empty:
                # Ordenar tentativas por data e hora para o gráfico
                tentativas_erro_usuario = tentativas_erro_usuario.sort_values(by=['Email', 'Data', 'Horário'])

                # Gráfico de linha do tempo com Plotly
                fig = px.line(
                    tentativas_erro_usuario,
                    x="Data", 
                    y="Horário", 
                    title=f"Linha do Tempo de Tentativas de Login com Erro - {usuario_input}",
                    labels={"Data": "Data", "Horário": "Horário"},
                    markers=True
                )
                fig.update_layout(xaxis_title="Data", yaxis_title="Horário da Tentativa")

                # Exibir o gráfico
                st.plotly_chart(fig)

                # Exibir os detalhes como boxes
                st.write("**Detalhes das tentativas de login com erro**")
                for index, row in tentativas_erro_usuario.iterrows():
                    st.markdown(
                        f"""
                        <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; background-color: #f9f9f9; margin-bottom: 10px;">
                            <strong>Email:</strong> {row['Email']}<br>
                            <strong>Data:</strong> {row['Data'].strftime('%Y-%m-%d')}<br>
                            <strong>Horário:</strong> {row['Horário']}<br>
                            <strong>Erro:</strong> {row['Error']}<br>
                            <strong>Client:</strong> {row['Client']}<br>
                        </div>
                        """, unsafe_allow_html=True
                    )
            else:
                st.info(f"Não há tentativas de login com erro para o usuário {usuario_input}.")
    else:
        st.error("Erro: O 'data' não é um DataFrame válido ou não contém a coluna 'Data'. Verifique se o arquivo foi carregado corretamente.")
