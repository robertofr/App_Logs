import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
import time


st.set_page_config(layout= 'wide')

with open("style.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html = True)

# Carregar os dados
data = pd.read_csv('dados_processados.csv')


# Função para obter data e hora atual formatada
def get_current_datetime():
    now = datetime.now()
    return now.strftime("%d/%m/%Y %H:%M:%S")

# Placeholder para o relógio
time_placeholder = st.empty()



#Cartões
# Converter a coluna 'Data' para o formato datetime, se necessário
data['Data'] = pd.to_datetime(data['Data'], errors='coerce')

# Número total de autenticações
total_autenticacoes = data.shape[0]

# Filtrar os dados para obter apenas as tentativas de login com erro na data de hoje
data_hoje = datetime.now().date()
erros_hoje = data[(data['Data'].dt.date == data_hoje) & (data['Status'] == 'Login incorrect')]

# Contar o número de erros de login de hoje
total_erros_hoje = erros_hoje.shape[0]

# Layout em colunas para os cartões
col1, col2 = st.columns(2)

# Cartão de Total de Autenticações
with col1:
    st.markdown(f"""
    <div class="card total-auth">
        <div class="metric-title">Total de Autenticações</div>
        <div class="metric-value">{total_autenticacoes}</div>
    </div>
    """, unsafe_allow_html=True)

######   GRÁFICO DE DISTRIBUIÇÃO POR CLIENTE #######

    # Renomear os valores da coluna 'Client'
    data['Client'] = data['Client'].replace({
        'wifi': 'Wifi Campus II',
        'wifi-c2': 'Wifi Campus II',
        'wifi-c1': 'Wifi Campus I',
        'wifi-c3': 'Wifi Campus III'
    })

    client_distribution = data['Client'].value_counts()
    st.markdown("<h3 style='text-align: center;'>Distribuição de autenticações por Cliente</h3>", unsafe_allow_html=True)

    # Usando Plotly para o gráfico de pizza com rótulos atualizados
    fig = px.pie(names=client_distribution.index, values=client_distribution.values)
    fig.update_traces(textinfo='percent+label')  # Exibir o rótulo e a porcentagem
    st.plotly_chart(fig)

###### TOP 5 ERROS DE AUTENTICAÇÕES #####

    # Converter a coluna 'Data' para o formato datetime, se necessário
    data['Data'] = pd.to_datetime(data['Data'], errors='coerce')

    # Título
    st.markdown("<h3 style='text-align: center;'>Top 5 Erros de Autenticação</h3>", unsafe_allow_html=True)

    # Opções de intervalo de tempo para visualização
    intervalo_opcoes = ['Total', 'Mês', 'Semana', 'Dia']
    intervalo_selecionado = st.selectbox("Selecione o intervalo de tempo", intervalo_opcoes)

    # Função para filtrar os dados com base no intervalo selecionado
    def filtrar_dados_por_intervalo(data, intervalo):
        data_hoje = datetime.now().date()
        
        if intervalo == 'Mês':
            data_inicio = data_hoje - timedelta(days=30)
        elif intervalo == 'Semana':
            data_inicio = data_hoje - timedelta(days=7)
        elif intervalo == 'Dia':
            data_inicio = data_hoje
        else:
            return data  # Total (sem filtro)
        
        return data[data['Data'].dt.date >= data_inicio]

    # Filtrar os dados de acordo com o intervalo selecionado
    dados_filtrados = filtrar_dados_por_intervalo(data, intervalo_selecionado)

    # Contar a ocorrência dos principais erros de autenticação
    erros_autenticacao = dados_filtrados[dados_filtrados['Status'] == 'Login incorrect']['Error'].value_counts().nlargest(5)

    # Verificar se há dados para exibir
    if not erros_autenticacao.empty:

        # Exibir erros em formato de lista estilizada
        st.markdown('<div class="error-list">', unsafe_allow_html=True)
        for error, count in erros_autenticacao.items():
            st.markdown(f"""
                <div class="error-item">
                    <div style="display: flex; align-items: center;">
                        <span class="error-icon">⚠️</span>
                        <div class="error-info">
                            <div class="error-name">{error}</div>
                        </div>
                    </div>
                    <div class="error-count-circle">{count}</div>
                </div>
            """, unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
    else:
        st.info("Nenhum erro de autenticação registrado para o intervalo selecionado.")

###### CARTÃO DE ERROS DE LOGIN IDENTIFICADOS HOJE #######
with col2:
    st.markdown(f"""
    <div class="card errors-today">
        <div class="metric-title">Erros Identificados Hoje</div>
        <div class="metric-value">{total_erros_hoje}</div>
    </div>
    """, unsafe_allow_html=True)

###### GRÁFICO DE ERROS DE AUTENTICAÇÃO ##############

    # Título
    st.markdown("<h3 style='text-align: center;'>Quantidade de Erros de Autenticação por Rede</h3>", unsafe_allow_html=True)

    # Filtrar apenas os erros de autenticação
    erros_login = data[data['Status'] == 'Login incorrect']

    # Contar os erros por rede
    erros_por_rede = erros_login['Client'].value_counts().reset_index()
    erros_por_rede.columns = ['Rede', 'Quantidade de Erros']

    # Renomear redes para nomes mais legíveis
    rede_renomeada = {
        'wifi-c1': 'Wifi Campus I',
        'wifi': 'Wifi Campus II',
        'wifi-c3': 'Wifi Campus III'
    }
    erros_por_rede['Rede'] = erros_por_rede['Rede'].replace(rede_renomeada)

    # Gráfico de barras
    fig = px.bar(
        erros_por_rede,
        x='Rede',
        y='Quantidade de Erros',
        color='Rede',
        text='Quantidade de Erros',
        #title='Quantidade de Erros de Autenticação por Rede',
        labels={'Rede': 'Rede', 'Quantidade de Erros': 'Quantidade'},
        template='plotly_white'
    )

    fig.update_traces(textposition='outside')  # Coloca os valores fora das barras para melhor visualização
    fig.update_layout(
        xaxis_title="Rede",
        yaxis_title="Quantidade de Erros",
        showlegend=False
    )

    # Exibir o gráfico no Streamlit
    st.plotly_chart(fig)


###### GRÁFICO CORRELAÇAO DE ERROS POR HORÁRIO #############

    # Título
    st.markdown("<h3 style='text-align: center;'>Correlação Entre Horário e Frequência de Erros</h3>", unsafe_allow_html=True)


    # Filtrar os erros de login Correlação de erros
    erros_login = data[data['Status'] == 'Login incorrect']

    # Extrair a hora das tentativas de login
    erros_login['Hora'] = pd.to_datetime(erros_login['Horário'], errors='coerce').dt.hour

    # Contar a frequência de erros por hora
    frequencia_erros_por_hora = erros_login.groupby('Hora').size().reset_index(name='Frequência de Erros')

    # Gráfico de dispersão para correlação entre horário e frequência de erros
    fig = px.scatter(
        frequencia_erros_por_hora,
        x='Hora',
        y='Frequência de Erros',
        size='Frequência de Erros',
        color='Frequência de Erros',
        #title="Correlação Entre Horário e Frequência de Erros",
        labels={'Hora': 'Hora do Dia', 'Frequência de Erros': 'Quantidade de Erros'}
    )

    fig.update_layout(
        xaxis=dict(tickmode='linear', tick0=0, dtick=1),  # Configura os ticks de hora
        xaxis_title="Hora do Dia",
        yaxis_title="Quantidade de Erros de Login",
        template="plotly_white"
    )

    # Exibir o gráfico no Streamlit
    st.plotly_chart(fig)


###### LOOP PARA ATUALIZAR A HORA CONTINUAMENTE #######
while True:
    current_time = get_current_datetime()
    time_placeholder.markdown(f"""
        <div class="header">
            <div class="title">Dashboard</div>
            <div class="datetime">{current_time}</div>
        </div>
    """, unsafe_allow_html=True)
    time.sleep(1)